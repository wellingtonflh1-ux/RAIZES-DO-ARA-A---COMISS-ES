create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null,
 role text not null default 'waiter' check (role in ('admin','waiter')),
 active boolean not null default true,
 created_at timestamptz not null default now()
);
create table if not exists public.commissions (
 id uuid primary key default gen_random_uuid(),
 waiter_id uuid not null references public.profiles(id) on delete restrict,
 work_date date not null,
 amount numeric(10,2) not null check (amount >= 0),
 note text,
 created_by uuid not null references auth.users(id),
 created_at timestamptz not null default now(),
 unique(waiter_id,work_date)
);
alter table public.profiles enable row level security;
alter table public.commissions enable row level security;
create or replace function public.current_user_role() returns text language sql security definer set search_path=public stable as $$ select role from public.profiles where id=auth.uid() and active=true limit 1; $$;
create or replace function public.is_active_user() returns boolean language sql security definer set search_path=public stable as $$ select exists(select 1 from public.profiles where id=auth.uid() and active=true); $$;
revoke all on function public.current_user_role() from public;
revoke all on function public.is_active_user() from public;
grant execute on function public.current_user_role() to authenticated;
grant execute on function public.is_active_user() to authenticated;
drop policy if exists "Profiles visible to active staff" on public.profiles;
create policy "Profiles visible to active staff" on public.profiles for select to authenticated using (public.is_active_user() and (id=auth.uid() or public.current_user_role()='admin'));
drop policy if exists "Admin manages profiles" on public.profiles;
create policy "Admin manages profiles" on public.profiles for all to authenticated using (public.current_user_role()='admin') with check (public.current_user_role()='admin');
drop policy if exists "Waiters see own commissions, admins see all" on public.commissions;
create policy "Waiters see own commissions, admins see all" on public.commissions for select to authenticated using (public.current_user_role()='admin' or waiter_id=auth.uid());
drop policy if exists "Admin inserts commissions" on public.commissions;
create policy "Admin inserts commissions" on public.commissions for insert to authenticated with check (public.current_user_role()='admin' and created_by=auth.uid());
drop policy if exists "Admin updates commissions" on public.commissions;
create policy "Admin updates commissions" on public.commissions for update to authenticated using (public.current_user_role()='admin') with check (public.current_user_role()='admin');
drop policy if exists "Admin deletes commissions" on public.commissions;
create policy "Admin deletes commissions" on public.commissions for delete to authenticated using (public.current_user_role()='admin');
grant select,insert,update,delete on public.profiles to authenticated;
grant select,insert,update,delete on public.commissions to authenticated;
