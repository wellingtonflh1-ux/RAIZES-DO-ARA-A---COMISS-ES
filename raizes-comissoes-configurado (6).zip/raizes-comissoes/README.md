# Raízes do Araçá — Portal de Comissões

Portal web responsivo com acesso por e-mail e senha, perfil de gerente e garçom, lançamento diário em lote e histórico por mês. Não possui status de pagamento.

## Conexão
1. Instale Node.js 20+.
2. Execute `npm install`.
3. Copie `.env.example` para `.env`.
4. Preencha `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` com a URL e chave pública do projeto Supabase.
5. Execute `npm run dev` para testar e `npm run build` para gerar a pasta `dist`.

Nunca coloque chave `service_role` ou `secret` no frontend.

## Banco e contas
O SQL de referência está em `supabase/schema.sql`. Como você já executou o script no projeto, não precisa executá-lo novamente. O gerente deve existir em `auth.users` e ter um perfil com `role='admin'`. Cada garçom precisa de conta criada em Authentication > Users e perfil com `role='waiter'`. Use SQL Editor para criar perfis; não habilite cadastro público. Criar contas Auth para os funcionários em produção deve ser feito pelo painel Supabase ou por função de servidor protegida, nunca expondo a chave service role no navegador.

## Publicação
Depois de preencher `.env`, publique o frontend Vite em Vercel, Netlify ou hospedagem equivalente, configure as mesmas variáveis no provedor e adicione a URL publicada nas configurações de URL do Supabase Auth. Antes do uso real, teste com contas separadas e valide as políticas RLS.
